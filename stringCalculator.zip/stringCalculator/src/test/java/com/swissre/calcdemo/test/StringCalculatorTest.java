package com.swissre.calcdemo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.swissre.calc.StringCalculator;

public class StringCalculatorTest {

	@Test
	public void testNull() {
		StringCalculator cal = new StringCalculator();
		int result = cal.stringcalc(null);
		assertEquals(0, result);
	}

	@Test
	public void testEmpty() {
		StringCalculator cal = new StringCalculator();
		int result = cal.stringcalc("");
		assertEquals(0, result);
	}
	
	@Test
	public void testPositiveIntegerCommaSeparated() {
		StringCalculator cal = new StringCalculator();
		int result = cal.stringcalc("1,2,3,15");
		assertEquals(21, result);
	}
	
	@Test
	public void testPositiveIntegerSpaceSeparated() {
		StringCalculator cal = new StringCalculator();
		int result = cal.stringcalc("1 2 3 15");
		assertEquals(21, result);
	}
	
	@Test
	public void testNegativeIntegers() {
		StringCalculator cal = new StringCalculator();
		int result = cal.stringcalc("-1 -2 -3");
		assertEquals(-1, result);
	}
	
	@Test
	public void testCombinationIntegers() {
		StringCalculator cal = new StringCalculator();
		int result = cal.stringcalc("1 2 3 -4");
		assertEquals(6, result);
	}
	
	@Test
	public void testBoundaryConditions1() {
		StringCalculator cal = new StringCalculator();
		int result = cal.stringcalc("-20");
		assertEquals(-1, result);
	}
	
	@Test
	public void testBoundaryConditions2() {
		StringCalculator cal = new StringCalculator();
		int result = cal.stringcalc("101");
		assertEquals(-1, result);
	}
}
