package com.swissre.calc;

import java.util.Arrays;
import java.util.OptionalInt;

public class StringCalculator {

	public int stringcalc(String input) {
		if (input == null || input.isEmpty()) {
			return 0;
		}
		return stringCalcDigit(input);
	}

	private int stringCalcDigit(String input) {
		OptionalInt resultOpt = Arrays.asList(input.replaceAll("[\\[\\]\\, ]", " ").split(" ")).stream()
				.mapToInt(Integer::parseInt).filter(i -> (i >= 0 && i <= 100)).reduce((a, b) -> a + b);
		if (resultOpt.isPresent()) {
			return resultOpt.getAsInt();
		} else {
			return -1;
		}
	}

	public static void main(String[] args) {
		String input = "-5 6 20 9";
		int result = new StringCalculator().stringcalc(input);
		System.out.println(result);
	}
}
